package com.example.andrisseaurelio.txungamoyo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myWebView = (WebView) findViewById(R.id.webview);

        webSttings WebSettings = myWebView.getSettings();
        //habilitar o javascript

        webSettings.setJavaSriptEnabled(true);


    }

     public boolean onCreateOptionsMenu(Menu menu){
         getMenuIflater().inflate(R.menu.main, menu)
                 return true;

    }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id== R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSlected(item);
    }
    public void click(View view) {
        android.widget.Toast.makeText(this, "Vce pressionou o botao", Toast.LENGTH_SHORT).show();
    }

}
